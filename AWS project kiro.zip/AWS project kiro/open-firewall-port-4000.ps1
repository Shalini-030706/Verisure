# VeriSure - Open port 4000 for mobile testing
# Run this script as Administrator

Write-Host "Adding Windows Firewall rule for VeriSure port 4000..." -ForegroundColor Cyan

# Remove old rule if exists
netsh advfirewall firewall delete rule name="VeriSure Port 4000" 2>

# Add new inbound rule
netsh advfirewall firewall add rule name="VeriSure Port 4000" dir=in action=allow protocol=TCP localport=4000

Write-Host ""
Write-Host "Done. Your phone can now reach the backend at:" -ForegroundColor Green
Write-Host "  http://192.168.44.66:4000/" -ForegroundColor Yellow
Write-Host ""
Write-Host "Press any key to exit..."
[Console]::ReadKey() | Out-Null