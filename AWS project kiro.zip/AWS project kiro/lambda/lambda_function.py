import json
import boto3

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("Products")


def lambda_handler(event, context):
    """
    VeriSure — Product Authenticity Verification
    Triggered by API Gateway POST /verify
    Expects JSON body: { "productId": "PROD1001" }
    """

    # Parse request body
    try:
        body = json.loads(event.get("body") or "{}")
    except json.JSONDecodeError:
        return _response(400, {"status": "error", "message": "Invalid JSON in request body"})

    product_id = body.get("productId", "").strip().upper()

    if not product_id:
        return _response(400, {"status": "error", "message": "productId is required"})

    # Query DynamoDB for the product
    result = table.get_item(Key={"productId": product_id})
    item = result.get("Item")

    if item:
        return _response(200, {
            "status":    "found",
            "productId": item["productId"],
            "name":      item["name"],
            "brand":     item["brand"],
            "batch":     item["batch"]
        })
    else:
        return _response(404, {
            "status":  "not_found",
            "message": "No record found for " + product_id
        })


def _response(status_code, body):
    """Helper that builds an API Gateway-compatible response with CORS headers."""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            # Allow the browser to call this API from any origin.
            # Restrict this to your domain when you go to production.
            "Access-Control-Allow-Origin": "*"
        },
        "body": json.dumps(body)
    }
