const API_SCANS = "http://localhost:4000/api/scans";
const statTotal   = document.getElementById("statTotal");
const statValid   = document.getElementById("statValid");
const statFailed  = document.getElementById("statFailed");
const historyBody = document.getElementById("historyBody");
const historyTable= document.getElementById("historyTable");
const emptyState  = document.getElementById("emptyState");
const refreshBtn  = document.getElementById("refreshBtn");
function esc(v){return String(v??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[c]);}
function fmtTime(iso){try{return new Date(iso).toLocaleString();}catch{return iso||"--";}}
function statusBadge(s){var m={VALID_RECORD:["badge-green","Verified"],NOT_FOUND:["badge-red","Not Found"],SUSPICIOUS:["badge-amber","Suspicious"],INVALID_INPUT:["badge-grey","Invalid"]};var e=m[s]||["badge-grey",s];return "<span class=\"badge "+e[0]+"\">"+e[1]+"</span>";}
async function loadHistory(){
  if(historyBody)historyBody.innerHTML="<tr><td colspan='3' style='text-align:center;padding:24px;color:#64748b'>Loading...</td></tr>";
  if(historyTable)historyTable.style.display="table";
  if(emptyState)emptyState.style.display="none";
  try{
    const r=await fetch(API_SCANS);const scans=await r.json();
    if(!Array.isArray(scans)||scans.length===0){
      if(statTotal)statTotal.textContent="0";if(statValid)statValid.textContent="0";if(statFailed)statFailed.textContent="0";
      if(historyTable)historyTable.style.display="none";if(emptyState)emptyState.style.display="block";return;
    }
    const valid=scans.filter(x=>x.status==="VALID_RECORD").length;
    const failed=scans.filter(x=>x.status!=="VALID_RECORD").length;
    if(statTotal)statTotal.textContent=scans.length;
    if(statValid)statValid.textContent=valid;
    if(statFailed)statFailed.textContent=failed;
    if(historyBody)historyBody.innerHTML=scans.map(x=>
      "<tr><td><code style='font-size:13px'>"+esc(x.productId||"N/A")+"</code></td>"+
      "<td>"+statusBadge(x.status)+"</td>"+
      "<td style='font-size:12px;color:#64748b'>"+esc(fmtTime(x.timestamp))+"</td></tr>"
    ).join("");
    if(historyTable)historyTable.style.display="table";
    if(emptyState)emptyState.style.display="none";
  }catch(e){
    if(statTotal)statTotal.textContent="--";if(statValid)statValid.textContent="--";if(statFailed)statFailed.textContent="--";
    if(historyBody)historyBody.innerHTML="<tr><td colspan='3' style='text-align:center;color:#dc2626;padding:24px'>Cannot connect to backend. Ensure it is running at localhost:4000.</td></tr>";
  }
}
if(refreshBtn)refreshBtn.addEventListener("click",loadHistory);
loadHistory();