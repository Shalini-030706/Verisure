﻿/* VeriSure - Public Verification (index.html) */
const API_BASE = "http://localhost:4000/api";
const VALID_ID = /^[A-Za-z0-9_-]{1,60}$/;
const form    = document.getElementById("verifyForm");
const inp     = document.getElementById("productId");
const res     = document.getElementById("result");
const btn     = document.getElementById("verifyBtn");
function esc(v){return String(v??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[c]);}
function show(type,h,b){res.style.display="block";res.className="result-box "+type;res.innerHTML="<h3>"+esc(h)+"</h3><p>"+esc(b)+"</p>";}
if(form){form.addEventListener("submit",async function(e){
  e.preventDefault();
  const id=inp.value.trim().toUpperCase();
  res.style.display="none";res.className="result-box";
  if(!id){show("error","Missing Product ID","Please enter a product ID to verify.");return;}
  if(!VALID_ID.test(id)){show("warning","Invalid Format","Enter a valid product ID (letters, digits, hyphens, underscores).");return;}
  btn.disabled=true;
  show("loading","Checking...","Looking up product record in the VeriSure registry.");
  try{
    const r=await fetch(API_BASE+"/products/"+encodeURIComponent(id));
    const d=await r.json();
    if(!r.ok){
      if(r.status===404){show("error","Product Not Found","No registered record found for "+esc(id)+". Its authenticity cannot be confirmed.");}
      else{show("error","Verification Error",d.error||"Could not complete verification.");}
      return;
    }
    res.style.display="block";res.className="result-box success";
    res.innerHTML=
      "<h3>&#x2705; Registered Product Record Found</h3>"+
      "<div class=\"result-row\"><span>Product ID</span><strong>"+esc(d.id)+"</strong></div>"+
      "<div class=\"result-row\"><span>Product Name</span><strong>"+esc(d.name)+"</strong></div>"+
      "<div class=\"result-row\"><span>Brand</span><strong>"+esc(d.brand)+"</strong></div>"+
      "<div class=\"result-row\"><span>Batch Number</span><strong>"+esc(d.batch)+"</strong></div>"+
      "<div class=\"result-row\"><span>Status</span><strong>"+esc(d.status||"REGISTERED")+"</strong></div>"+
      "<p class=\"result-note\">This product exists in the VeriSure registry. For full cryptographic verification, scan the product QR code.</p>";
  }catch(err){show("error","Backend Unavailable","Cannot connect to VeriSure backend. Make sure it is running at localhost:4000.");}
  finally{btn.disabled=false;}
});}