/* VeriSure - Admin Dashboard (admin.html) */
const API = "http://localhost:4000/api";
const VALID_ID = /^[A-Za-z0-9_-]{1,60}$/;
let allProducts = [];
let currentQRUrl = "";

function esc(v){return String(v??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[c]);}
function setText(id,v){var el=document.getElementById(id);if(el)el.textContent=v;}

function showSection(id){
  ["section-dashboard","section-register","section-products"].forEach(function(s){
    var el=document.getElementById(s);if(el)el.style.display=(s===id?"block":"none");
  });
  document.querySelectorAll(".sidebar-link[data-section]").forEach(function(a){
    a.classList.toggle("active",a.dataset.section===id);
  });
}
document.querySelectorAll(".sidebar-link[data-section]").forEach(function(a){
  a.addEventListener("click",function(e){e.preventDefault();showSection(a.dataset.section);});
});

function statusBadge(s){var m={VALID_RECORD:["badge-green","Verified"],NOT_FOUND:["badge-red","Not Found"],SUSPICIOUS:["badge-amber","Suspicious"],INVALID_INPUT:["badge-grey","Invalid"]};var e=m[s]||["badge-grey",s];return "<span class=\"badge "+e[0]+"\">"+e[1]+"</span>";}
function fmtTime(iso){try{return new Date(iso).toLocaleString();}catch{return iso||"--";}}

async function loadStats(){
  try{
    const [pr,sr]=await Promise.all([fetch(API+"/products"),fetch(API+"/scans")]);
    const products=await pr.json();const scans=await sr.json();
    allProducts=Array.isArray(products)?products:[];
    var sc=Array.isArray(scans)?scans:[];
    setText("statProducts",allProducts.length);
    setText("statVerified",sc.filter(function(s){return s.status==="VALID_RECORD";}).length);
    setText("statFailed",sc.filter(function(s){return s.status==="NOT_FOUND"||s.status==="INVALID_INPUT";}).length);
    setText("statSuspicious",sc.filter(function(s){return s.status==="SUSPICIOUS";}).length);
    renderProductTable(allProducts);renderRecentScans(sc.slice(0,5));
  }catch(err){console.error("Stats load failed",err);}
}

function renderProductTable(products){
  var tbody=document.getElementById("productTableBody");
  var empty=document.getElementById("productEmpty");
  var count=document.getElementById("productCount");
  if(!tbody)return;
  if(count)count.textContent=products.length+" product"+(products.length!==1?"s":"");
  if(products.length===0){tbody.innerHTML="";if(empty)empty.style.display="block";return;}
  if(empty)empty.style.display="none";
  tbody.innerHTML=products.map(function(p){
    return "<tr>"+
      "<td><code style='font-size:13px'>"+esc(p.id)+"</code></td>"+
      "<td>"+esc(p.name)+"</td>"+
      "<td>"+esc(p.brand)+"</td>"+
      "<td>"+esc(p.batch)+"</td>"+
      "<td><span class=\"badge badge-green\">"+esc(p.status||"REGISTERED")+"</span></td>"+
      "<td><button class=\"table-btn\" data-product-id=\""+esc(p.id)+"\">&#x1F4F7; QR</button></td>"+
    "</tr>";
  }).join("");
  tbody.querySelectorAll(".table-btn[data-product-id]").forEach(function(btn){
    btn.addEventListener("click",function(){openQR(btn.getAttribute("data-product-id"));});
  });
}

function renderRecentScans(scans){
  var tbody=document.getElementById("recentScansBody");if(!tbody)return;
  if(scans.length===0){tbody.innerHTML="<tr><td colspan='3' style='text-align:center;color:#64748b;padding:20px'>No scans yet</td></tr>";return;}
  tbody.innerHTML=scans.map(function(s){
    return "<tr>"+
      "<td><code style='font-size:13px'>"+esc(s.productId)+"</code></td>"+
      "<td>"+statusBadge(s.status)+"</td>"+
      "<td style='font-size:12px;color:#64748b'>"+esc(fmtTime(s.timestamp))+"</td>"+
    "</tr>";
  }).join("");
}

var searchInput=document.getElementById("productSearch");
if(searchInput){
  searchInput.addEventListener("input",function(){
    var q=this.value.trim().toLowerCase();
    renderProductTable(q?allProducts.filter(function(p){
      return (p.id||"").toLowerCase().includes(q)||(p.name||"").toLowerCase().includes(q)||(p.brand||"").toLowerCase().includes(q);
    }):allProducts);
  });
}

/* ---- QR Modal ---- */
function showQRModal(){
  var overlay=document.getElementById("qrModal");
  if(overlay)overlay.classList.add("open");
}
function closeQRModal(){
  var overlay=document.getElementById("qrModal");
  if(overlay)overlay.classList.remove("open");
}

async function openQR(productId){
  var body=document.getElementById("qrModalBody");
  if(!body){console.error("qrModalBody not found");return;}

  // Show loading state immediately
  body.innerHTML="<div style='padding:24px;color:#64748b;font-size:14px'>"+
    "<div style='font-size:32px;margin-bottom:12px'>&#x23F3;</div>"+
    "<p>Generating QR code for "+esc(productId)+"...</p>"+
  "</div>";
  showQRModal();

  try{
    var r=await fetch(API+"/products/"+encodeURIComponent(productId)+"/qr");
    var d=await r.json();
    if(!r.ok)throw new Error(d.error||"QR generation failed (HTTP "+r.status+")");
    if(!d.qrDataUrl)throw new Error("Backend did not return a QR image.");

    var prod=allProducts.find(function(p){return p.id===productId;})||{};
    currentQRUrl=d.verificationUrl||"";

    // Build modal content - all event handlers added via addEventListener (no inline onclick)
    body.innerHTML=
      "<div style='margin-bottom:16px;text-align:left'>"+
        "<p style='font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px'>Product</p>"+
        "<p style='font-size:17px;font-weight:700;color:#0f2137;margin-bottom:4px'>"+esc(prod.name||productId)+"</p>"+
        "<p style='font-size:13px;color:#64748b'>"+
          "ID: <strong style='color:#1e293b'>"+esc(productId)+"</strong>"+
          "&emsp;Batch: <strong style='color:#1e293b'>"+esc(prod.batch||"N/A")+"</strong>"+
        "</p>"+
      "</div>"+
      "<div id='qrImageWrap' style='cursor:pointer;display:inline-block;line-height:0' title='Click to open verification page' tabindex='0' role='button' aria-label='Open verification page for "+esc(productId)+"'>"+
        "<img id='qrImg' src='"+d.qrDataUrl+"' width='220' height='220' alt='QR code for "+esc(productId)+"'"+
        " style='border-radius:10px;border:3px solid #e2e8f0;transition:box-shadow .15s;max-width:100%;height:auto'>"+
      "</div>"+
      "<p style='font-size:12px;color:#64748b;margin-top:10px'>&#x1F4F1; Tap or click the QR image to open the verification page</p>"+
      "<div style='margin-top:18px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap'>"+
        "<button id='btnOpenVerify' style='background:#2563eb;color:white;border:none;padding:10px 18px;border-radius:7px;font-size:13px;font-weight:600;cursor:pointer'>&#x1F517; Open Verification Page</button>"+
        "<a id='btnDownload' href='"+d.qrDataUrl+"' download='"+esc(productId)+"-QR.png'"+
          " style='text-decoration:none;padding:10px 18px;border:1.5px solid #e2e8f0;border-radius:7px;font-size:13px;font-weight:600;color:#1e293b;background:#f8fafc;display:inline-flex;align-items:center;gap:6px'>&#x2B07; Download QR</a>"+
        "<button id='btnPrint' style='background:#f8fafc;color:#1e293b;border:1.5px solid #e2e8f0;padding:10px 18px;border-radius:7px;font-size:13px;font-weight:600;cursor:pointer'>&#x1F5A8; Print QR</button>"+
      "</div>"+
      "<details style='margin-top:14px;text-align:left'>"+
        "<summary style='font-size:12px;color:#64748b;cursor:pointer'>Show verification URL</summary>"+
        "<code style='display:block;background:#f1f5f9;padding:8px;border-radius:6px;font-size:11px;word-break:break-all;margin-top:6px;color:#1e293b'>"+esc(d.verificationUrl)+"</code>"+
      "</details>";

    // Attach all event handlers via addEventListener - NO inline onclick
    var wrap=document.getElementById("qrImageWrap");
    if(wrap){
      wrap.addEventListener("click",function(){if(currentQRUrl)window.open(currentQRUrl,"_blank");});
      wrap.addEventListener("keydown",function(ev){
        if((ev.key==="Enter"||ev.key===" ")&&currentQRUrl){ev.preventDefault();window.open(currentQRUrl,"_blank");}
      });
      wrap.addEventListener("mouseover",function(){
        var img=this.querySelector("img");if(img)img.style.boxShadow="0 0 0 4px #2563eb";
      });
      wrap.addEventListener("mouseout",function(){
        var img=this.querySelector("img");if(img)img.style.boxShadow="none";
      });
      wrap.addEventListener("focus",function(){
        var img=this.querySelector("img");if(img)img.style.boxShadow="0 0 0 4px #2563eb";
      });
      wrap.addEventListener("blur",function(){
        var img=this.querySelector("img");if(img)img.style.boxShadow="none";
      });
    }
    var btnOpen=document.getElementById("btnOpenVerify");
    if(btnOpen)btnOpen.addEventListener("click",function(){if(currentQRUrl)window.open(currentQRUrl,"_blank");});
    var btnPrint=document.getElementById("btnPrint");
    if(btnPrint)btnPrint.addEventListener("click",function(){printQR();});

  }catch(err){
    console.error("QR generation error:",err);
    body.innerHTML=
      "<div style='padding:16px;text-align:center'>"+
        "<div style='font-size:32px;margin-bottom:12px'>&#x26A0;&#xFE0F;</div>"+
        "<p style='color:#dc2626;font-weight:600;margin-bottom:8px'>QR Generation Failed</p>"+
        "<p style='color:#64748b;font-size:13px;margin-bottom:16px'>"+esc(err.message)+"</p>"+
        "<button id='btnRetry' style='background:#2563eb;color:white;border:none;padding:9px 18px;border-radius:7px;font-size:13px;font-weight:600;cursor:pointer'>&#x21BB; Retry</button>"+
      "</div>";
    var btnRetry=document.getElementById("btnRetry");
    if(btnRetry)btnRetry.addEventListener("click",function(){openQR(productId);});
  }
}

function printQR(){
  var img=document.getElementById("qrImg");
  if(!img){console.warn("No QR image found");return;}
  var w=window.open("","_blank");
  if(!w){alert("Pop-up blocked. Please allow pop-ups for this page.");return;}
  w.document.write(
    "<html><head><title>VeriSure QR Code</title>"+
    "<style>body{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;margin:0;font-family:Arial,sans-serif;gap:12px}"+
    "img{border:4px solid #0f2137;border-radius:8px}p{color:#64748b;font-size:13px;text-align:center}</style></head>"+
    "<body><img src=\""+img.src+"\" width=\"280\" height=\"280\">"+
    "<p>VeriSure &mdash; Scan to verify product authenticity</p>"+
    "<script>window.onload=function(){window.print();window.close();}<\/script>"+
    "</body></html>"
  );
  w.document.close();
}

// Close handlers
var qrModalEl=document.getElementById("qrModal");
var qrCloseEl=document.getElementById("qrModalClose");
if(qrCloseEl)qrCloseEl.addEventListener("click",closeQRModal);
if(qrModalEl){
  qrModalEl.addEventListener("click",function(e){
    if(e.target===e.currentTarget)closeQRModal();
  });
}
document.addEventListener("keydown",function(e){
  if(e.key==="Escape")closeQRModal();
});

/* ---- Registration Form ---- */
var regForm=document.getElementById("registerForm");
var regResult=document.getElementById("registerResult");
function showReg(type,heading,bodyHtml){
  if(!regResult)return;
  regResult.style.display="block";
  regResult.className="result-box "+type;
  regResult.innerHTML="<h3>"+heading+"</h3><p>"+bodyHtml+"</p>";
}
if(regForm){
  regForm.addEventListener("submit",async function(e){
    e.preventDefault();
    var id=document.getElementById("newProductId").value.trim().toUpperCase();
    var name=document.getElementById("newProductName").value.trim();
    var brand=document.getElementById("newBrand").value.trim();
    var batch=document.getElementById("newBatch").value.trim();
    if(!id){showReg("error","Missing Product ID","Enter a product ID.");return;}
    if(!VALID_ID.test(id)){showReg("warning","Invalid ID Format","Use letters, digits, hyphens or underscores (max 60 chars).");return;}
    if(!name||!brand||!batch){showReg("error","Missing Fields","All four fields are required.");return;}
    var sbtn=regForm.querySelector("[type=submit]");if(sbtn)sbtn.disabled=true;
    try{
      var r=await fetch(API+"/products",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id,name,brand,batch})});
      var d=await r.json();
      if(!r.ok){showReg("warning",esc(d.error||"Registration Failed"),"Check the details and try again.");return;}
      showReg("success","&#x2705; Product Registered",
        "<strong>ID:</strong> "+esc(d.product.id)+"<br><strong>Name:</strong> "+esc(d.product.name)+
        "<br><strong>Brand:</strong> "+esc(d.product.brand)+"<br><strong>Batch:</strong> "+esc(d.product.batch)+
        "<br><em style='font-size:12px'>Registration does not by itself prove physical authenticity.</em>");
      regForm.reset();await loadStats();await openQR(id);showSection("section-products");
    }catch(err){
      showReg("error","Backend Unavailable","Cannot connect to backend at localhost:4000.");
    }finally{if(sbtn)sbtn.disabled=false;}
  });
}

/* ---- Hamburger ---- */
var hamburgerBtn=document.getElementById("hamburger");
if(hamburgerBtn){
  hamburgerBtn.addEventListener("click",function(){
    var navLinks=document.getElementById("navLinks");
    if(navLinks)navLinks.classList.toggle("open");
  });
}

/* ---- Init ---- */
showSection("section-dashboard");
loadStats();