# VeriSure - Smart Product Authenticity Verification System

A full-stack web application that lets administrators register products, generate QR codes, and lets customers verify product authenticity using cryptographic signatures.

---

## Quick Start

**1. Install dependencies (first time only)**
`
cd "c:\AWS project kiro\backend"
npm install
`

**2. Start the backend**
`
cd "c:\AWS project kiro\backend"
node server.js
`

Keep this terminal open. The server runs on port 4000.

**3. Open in browser**

| Page | URL |
|---|---|
| Home / Verify | http://localhost:4000/ |
| Admin Dashboard | http://localhost:4000/admin.html |
| QR Scan Result | http://localhost:4000/verify.html |
| Scan History | http://localhost:4000/history.html |
| Health Check | http://localhost:4000/api/health |

---

## Features

- **Product Registration** - Admin registers products (ID, name, brand, batch)
- **HMAC-SHA256 Signing** - Backend signs each product with a secret key
- **QR Code Generation** - Each product gets a downloadable QR code
- **Product Verification** - Lookup by ID or scan QR code for full cryptographic check
- **Scan History** - Every verification attempt is recorded
- **Dashboard Statistics** - Real counts from actual data

---

## Technology Stack

- **Backend:** Node.js, Express 5, dotenv, qrcode
- **Signing:** Node.js crypto (HMAC-SHA256)
- **Storage:** JSON files (backend/products.json, backend/scans.json)
- **Frontend:** HTML5, CSS3, Vanilla JavaScript, Fetch API

---

## Project Structure

`
c:\AWS project kiro\
  backend\
    server.js          Express API server
    .env               Signing secret + public URL config
    products.json      Registered product records (persistent)
    scans.json         Verification scan history (persistent)
  Product-Authenticity-Verification\
    index.html         Home page + product lookup
    admin.html         Admin dashboard (stats, register, product list)
    verify.html        QR scan landing page (full signature verification)
    history.html       Scan history with statistics
    style.css          Shared design system
    admin.css          Admin layout additions
    script.js          Home page verification logic
    admin.js           Admin dashboard logic
    history.js         History page logic
`

---

## Environment Configuration (backend/.env)

`
VERISURE_SIGNING_SECRET=<your-long-random-secret>
PUBLIC_BASE_URL=http://localhost:4000
`

For phone testing over Wi-Fi, change PUBLIC_BASE_URL to your laptop's local IP:
`
PUBLIC_BASE_URL=http://192.168.x.x:4000
`
Find your IP with: ipconfig (look for IPv4 Address under Wi-Fi adapter)

---

## API Endpoints

| Method | Path | Description |
|---|---|---|
| GET | /api/health | Server status |
| GET | /api/products | List all products (no signatures) |
| POST | /api/products | Register new product |
| GET | /api/products/:id | Get single product |
| GET | /api/products/:id/qr | Generate QR code |
| GET | /api/products/:id/signature-check | Diagnose signature status |
| POST | /api/verify | Verify product with signature |
| GET | /api/scans | Recent scan history (last 100) |

**POST /api/products** body:
`json
{ "id": "PROD2001", "name": "Bluetooth Speaker", "brand": "SoundWave", "batch": "BATCH-A001" }
`

**POST /api/verify** body:
`json
{ "id": "PROD2001", "signature": "<64-char-hex-from-qr>" }
`

---

## How Verification Works

1. Admin registers a product - backend signs it with HMAC-SHA256
2. Admin clicks "QR" - backend generates a URL with id + signature
3. QR code encodes that URL pointing to /verify.html
4. Customer scans QR - browser opens /verify.html with id + signature in URL
5. verify.html sends POST /api/verify to backend
6. Backend checks signature against stored record and current signing logic
7. Result: VALID_RECORD (green), NOT_FOUND (red), or SUSPICIOUS (amber)

The signing secret never leaves the server. Signatures cannot be forged without it.

---

## Limitations (College Demo)

- No user authentication on admin routes (demo only)
- JSON file storage is not suitable for production concurrency
- HTTP only - use HTTPS before any public deployment
- PUBLIC_BASE_URL must be updated for phone testing over Wi-Fi

---

## Educational Project

VeriSure was built as a college final year project demonstrating full-stack development,
REST APIs, cryptographic product signing, and QR-based verification.