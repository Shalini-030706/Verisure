require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const crypto  = require('crypto');
const fs      = require('fs');
const path    = require('path');
const QRCode  = require('qrcode');

const app    = express();
const PORT   = Number(process.env.PORT) || 4000;
const SECRET = process.env.VERISURE_SIGNING_SECRET;

if (!SECRET) {
  console.error('ERROR: VERISURE_SIGNING_SECRET missing in backend/.env');
  process.exit(1);
}

app.use(cors());
app.use(express.json());

// Frontend is served from the Product-Authenticity-Verification subfolder.
// All HTML, CSS, and JS files live there.
const FRONTEND_DIR = path.resolve(__dirname, '..', 'Product-Authenticity-Verification');
app.use(express.static(FRONTEND_DIR));

const productsFile = path.join(__dirname, 'products.json');
const scansFile    = path.join(__dirname, 'scans.json');

function readJson(file, fallback = []) {
  try {
    if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(fallback, null, 2));
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (error) {
    console.error('[FILE ERROR]', file, error.message);
    throw error;
  }
}

function saveJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function validId(id) {
  return typeof id === 'string' && /^[A-Za-z0-9_-]{1,60}$/.test(id);
}

function signProduct(product) {
  const payload = {
    id:    String(product.id    || ''),
    name:  String(product.name  || ''),
    brand: String(product.brand || ''),
    batch: String(product.batch || product.batchNumber || '')
  };
  return crypto.createHmac('sha256', SECRET).update(JSON.stringify(payload)).digest('hex');
}

function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  if (!/^[a-f0-9]{64}$/i.test(a) || !/^[a-f0-9]{64}$/i.test(b)) return false;
  return crypto.timingSafeEqual(Buffer.from(a, 'hex'), Buffer.from(b, 'hex'));
}

function publicProduct(product) {
  const { signature, ...safe } = product;
  return safe;
}

function logScan(id, status) {
  const scans = readJson(scansFile, []);
  scans.unshift({ productId: id || 'UNKNOWN', status, timestamp: new Date().toISOString() });
  saveJson(scansFile, scans.slice(0, 1000));
}

// ── API Routes ────────────────────────────────────────────────────────────────

app.get('/api/health', (req, res) => {
  res.json({ message: 'VeriSure backend is running', port: PORT, qrRouteVersion: 'v4' });
});

app.get('/api/products', (req, res) => {
  try {
    res.json(readJson(productsFile, []).map(publicProduct));
  } catch (e) {
    res.status(500).json({ error: 'Could not read products.' });
  }
});

app.post('/api/products', (req, res) => {
  const { id, name, brand } = req.body || {};
  const batchValue = req.body?.batch || req.body?.batchNumber;
  if (!validId(id) ||
      typeof name !== 'string' || !name.trim() ||
      typeof brand !== 'string' || !brand.trim() ||
      typeof batchValue !== 'string' || !batchValue.trim()) {
    return res.status(400).json({ error: 'Valid id, name, brand and batch are required.' });
  }
  try {
    const products = readJson(productsFile, []);
    const cleanId  = id.trim();
    if (products.some(p => p.id === cleanId)) {
      return res.status(409).json({ error: 'Product ID already exists.' });
    }
    const product = {
      id: cleanId, name: name.trim(), brand: brand.trim(), batch: batchValue.trim(),
      status: 'REGISTERED', createdAt: new Date().toISOString()
    };
    product.signature = signProduct(product);
    products.push(product);
    saveJson(productsFile, products);
    return res.status(201).json({ message: 'Product registered successfully', product: publicProduct(product) });
  } catch (e) {
    return res.status(500).json({ error: 'Could not register product.' });
  }
});

app.get('/api/products/:id/signature-check', (req, res) => {
  try {
    const products = readJson(productsFile, []);
    const product  = products.find(p => p.id === req.params.id);
    if (!product) return res.status(404).json({ error: 'Product not found.' });
    const expected = signProduct(product);
    return res.json({
      id: product.id,
      hasStoredSignature: typeof product.signature === 'string',
      matchesCurrentLogic: safeEqual(product.signature, expected),
      fieldsPresent: { id: !!product.id, name: !!product.name, brand: !!product.brand, batch: !!product.batch }
    });
  } catch (e) {
    return res.status(500).json({ error: 'Could not check signature.' });
  }
});

app.get('/api/products/:id/qr', async (req, res) => {
  const id = req.params.id;
  if (!validId(id)) return res.status(400).json({ error: 'Invalid product ID.' });
  try {
    const products = readJson(productsFile, []);
    const product  = products.find(p => p.id === id);
    if (!product) return res.status(404).json({ error: 'Product not found.', id });
    const expected = signProduct(product);
    if (!safeEqual(product.signature, expected)) {
      return res.status(409).json({
        error: 'Signature mismatch.', id,
        diagnosticUrl: `/api/products/${encodeURIComponent(id)}/signature-check`
      });
    }
    const baseUrl = (process.env.PUBLIC_BASE_URL || `http://localhost:${PORT}`).replace(/\/+$/, '');
    const url = new URL(`${baseUrl}/verify.html`);
    url.searchParams.set('id', product.id);
    url.searchParams.set('signature', product.signature);
    const qrDataUrl = await QRCode.toDataURL(url.toString());
    return res.json({ id: product.id, qrDataUrl, verificationUrl: url.toString() });
  } catch (e) {
    console.error('[QR ERROR]', e);
    return res.status(500).json({ error: 'QR generation failed.' });
  }
});

app.get('/api/products/:id', (req, res) => {
  try {
    const product = readJson(productsFile, []).find(p => p.id === req.params.id);
    if (!product) return res.status(404).json({ error: 'Product not found.' });
    return res.json(publicProduct(product));
  } catch (e) {
    return res.status(500).json({ error: 'Could not read product.' });
  }
});

app.post('/api/verify', (req, res) => {
  const { id, signature } = req.body || {};
  if (!validId(id) || typeof signature !== 'string') {
    try { logScan(id, 'INVALID_INPUT'); } catch (e) {}
    return res.status(400).json({ verified: false, status: 'INVALID_INPUT', message: 'Invalid input.' });
  }
  try {
    const product = readJson(productsFile, []).find(p => p.id === id);
    if (!product) {
      logScan(id, 'NOT_FOUND');
      return res.status(404).json({ verified: false, status: 'NOT_FOUND', message: 'This product is not registered.' });
    }
    const expected = signProduct(product);
    const valid = safeEqual(signature, product.signature) && safeEqual(signature, expected);
    if (!valid) {
      logScan(id, 'SUSPICIOUS');
      return res.json({ verified: false, status: 'SUSPICIOUS', message: 'Product signature could not be verified.' });
    }
    logScan(id, 'VALID_RECORD');
    return res.json({ verified: true, status: 'VALID_RECORD', message: 'Product Verified Successfully!', product: publicProduct(product) });
  } catch (e) {
    return res.status(500).json({ verified: false, status: 'ERROR', message: 'Verification service unavailable.' });
  }
});

app.get('/api/scans', (req, res) => {
  try {
    res.json(readJson(scansFile, []).slice(0, 100));
  } catch (e) {
    res.status(500).json({ error: 'Could not read scan history.' });
  }
});

// ── HTML page routes ──────────────────────────────────────────────────────────
// Explicit routes ensure pages are found even when express.static
// does not serve a default index (Express 5 behaviour).

app.get(['/', '/index.html'], (req, res) => {
  res.sendFile(path.join(FRONTEND_DIR, 'index.html'));
});
app.get('/admin.html', (req, res) => {
  res.sendFile(path.join(FRONTEND_DIR, 'admin.html'));
});
app.get('/verify.html', (req, res) => {
  res.sendFile(path.join(FRONTEND_DIR, 'verify.html'));
});
app.get('/history.html', (req, res) => {
  res.sendFile(path.join(FRONTEND_DIR, 'history.html'));
});

// ── Unknown API route ─────────────────────────────────────────────────────────
app.use('/api', (req, res) => {
  res.status(404).json({ error: 'API endpoint not found', path: req.originalUrl });
});

// ── Start server ──────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log('---------------------------------------');
  console.log('VeriSure backend started successfully');
  console.log('Port           :', PORT);
  console.log('Frontend dir   :', FRONTEND_DIR);
  console.log('Home page      :', `http://localhost:${PORT}/`);
  console.log('Admin page     :', `http://localhost:${PORT}/admin.html`);
  console.log('Verify page    :', `http://localhost:${PORT}/verify.html`);
  console.log('History page   :', `http://localhost:${PORT}/history.html`);
  console.log('Health check   :', `http://localhost:${PORT}/api/health`);
  console.log('---------------------------------------');
});