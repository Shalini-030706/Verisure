
const API_URL = "http://localhost:4000/api/products";
const VALID_ID_FORMAT = /^PROD\d{1,8}$/;

const form = document.getElementById("registerForm");
const inputId = document.getElementById("newProductId");
const inputName = document.getElementById("newProductName");
const inputBrand = document.getElementById("newBrand");
const inputBatch = document.getElementById("newBatch");
const resultBox = document.getElementById("registerResult");
const registryList = document.getElementById("registryList");

function showResult(type, html) {
    resultBox.className = "result " + type;
    resultBox.innerHTML = html;
}

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);
}

// Generate and display QR code for a registered product
async function showQRCode(productId) {
    try {
        const response = await fetch(
            `${API_URL}/${encodeURIComponent(productId)}/qr`
        );

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || "QR generation failed.");
        }

        const qrSection = document.getElementById("qrSection");
        if (!qrSection) {
            showResult("error",
                "<h3>QR section missing</h3>" +
                "<p>Add the QR section to admin.html first.</p>");
            return;
        }

        qrSection.replaceChildren();

        const heading = document.createElement("h3");
        heading.textContent = "Product QR Code";

        const details = document.createElement("p");
        details.textContent = `Product ID: ${data.id}`;

        const image = document.createElement("img");
        image.src = data.qrDataUrl;
        image.alt = `QR code for ${data.id}`;
        image.width = 220;
        image.height = 220;

        const downloadLink = document.createElement("a");
        downloadLink.href = data.qrDataUrl;
        downloadLink.download = `${data.id}-QR.png`;
        downloadLink.textContent = "Download QR Code";
        downloadLink.className = "qr-download";

        qrSection.append(heading, details, image, downloadLink);
        qrSection.hidden = false;
        qrSection.scrollIntoView({ behavior: "smooth", block: "center" });

    } catch (error) {
        showResult("error",
            "<h3>QR Code Error</h3><p>" +
            escapeHTML(error.message) + "</p>");
    }
}

async function renderRegistry() {
    try {
        const response = await fetch(API_URL);

        if (!response.ok) {
            throw new Error("Could not load product records.");
        }

        const products = await response.json();

        if (!Array.isArray(products) || products.length === 0) {
            registryList.textContent = "No products registered yet.";
            return;
        }

        const table = document.createElement("table");
        table.className = "registry-table";

        const thead = table.createTHead();
        const headerRow = thead.insertRow();

        [
            "Product ID",
            "Product Name",
            "Brand",
            "Batch Number",
            "Source",
            "QR Code"
        ].forEach(label => {
            const th = document.createElement("th");
            th.textContent = label;
            headerRow.appendChild(th);
        });

        const tbody = table.createTBody();

        products.forEach(product => {
            const row = tbody.insertRow();

            [
                product.id,
                product.name,
                product.brand,
                product.batch,
                "Backend"
            ].forEach(value => {
                const cell = row.insertCell();
                cell.textContent = value ?? "";
            });

            const qrCell = row.insertCell();
            const qrButton = document.createElement("button");
            qrButton.type = "button";
            qrButton.textContent = "View QR";
            qrButton.addEventListener("click", () => showQRCode(product.id));
            qrCell.appendChild(qrButton);
        });

        registryList.replaceChildren(table);

    } catch (error) {
        registryList.textContent =
            "Cannot load records. Check whether the backend is running.";
    }
}

form.addEventListener("submit", async event => {
    event.preventDefault();

    const id = inputId.value.trim().toUpperCase();
    const name = inputName.value.trim();
    const brand = inputBrand.value.trim();
    const batch = inputBatch.value.trim();

    if (!id) {
        showResult("error",
            "<h3>Missing Product ID</h3><p>Enter a Product ID.</p>");
        return;
    }

    if (!VALID_ID_FORMAT.test(id)) {
        showResult("warning",
            "<h3>Invalid Product ID Format</h3>" +
            "<p>Use PROD followed by 1–8 digits, e.g. PROD2001.</p>");
        return;
    }

    if (!name || !brand || !batch) {
        showResult("error",
            "<h3>Missing Fields</h3>" +
            "<p>Fill in Product Name, Brand, and Batch Number.</p>");
        return;
    }

    const submitButton = form.querySelector('[type="submit"]');
    if (submitButton) submitButton.disabled = true;

    try {
        const response = await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id, name, brand, batch })
        });

        const data = await response.json();

        if (!response.ok) {
            showResult("warning",
                "<h3>" +
                escapeHTML(data.error || data.message || "Registration failed") +
                "</h3><p>Please check the details and try again.</p>");
            return;
        }

        showResult("success",
            "<h3>Product Record Registered</h3>" +
            "<p><strong>Product ID:</strong> " + escapeHTML(data.product.id) + "</p>" +
            "<p><strong>Product Name:</strong> " + escapeHTML(data.product.name) + "</p>" +
            "<p><strong>Brand:</strong> " + escapeHTML(data.product.brand) + "</p>" +
            "<p><strong>Batch:</strong> " + escapeHTML(data.product.batch) + "</p>" +
            "<p>Registration does not by itself prove physical authenticity.</p>"
        );

        form.reset();
        await renderRegistry();
        await showQRCode(id);

    } catch (error) {
        showResult("error",
            "<h3>Backend Connection Failed</h3>" +
            "<p>Make sure the server is running at localhost:4000.</p>");
    } finally {
        if (submitButton) submitButton.disabled = false;
    }
});

renderRegistry();
