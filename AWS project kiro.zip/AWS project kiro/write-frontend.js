﻿// VeriSure frontend writer - executed once then deleted
