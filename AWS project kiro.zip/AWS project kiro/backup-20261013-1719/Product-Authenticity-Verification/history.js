/* VeriSure - Scan History Page */
const API_SCANS    = "http://localhost:4000/api/scans";
const API_PRODUCTS = "http://localhost:4000/api/products";

const statTotal    = document.getElementById("statTotal");
const statValid    = document.getElementById("statValid");
const statFailed   = document.getElementById("statFailed");
const historyBody  = document.getElementById("historyBody");
const historyTable = document.getElementById("historyTable");
const emptyState   = document.getElementById("emptyState");
const refreshBtn   = document.getElementById("refreshBtn");

function formatTime(iso) {
    try {
        return new Date(iso).toLocaleString();
    } catch { return iso || "Unknown"; }
}

function statusBadge(status) {
    const labels = {
        VALID_RECORD:  "Verified",
        NOT_FOUND:     "Not Found",
        SUSPICIOUS:    "Suspicious",
        INVALID_INPUT: "Invalid Input"
    };
    const label = labels[status] || status;
    return '<span class="status-badge ' + status + '">' + label + '</span>';
}

function escapeHTML(v) {
    return String(v ?? "").replace(/[&<>"']/g, c =>
        ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[c]);
}

async function loadHistory() {
    historyBody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:#64748b;padding:20px">Loading...</td></tr>';
    historyTable.hidden = false;
    emptyState.hidden   = true;

    try {
        const resp  = await fetch(API_SCANS);
        const scans = await resp.json();

        if (!Array.isArray(scans) || scans.length === 0) {
            statTotal.textContent = "0";
            statValid.textContent = "0";
            statFailed.textContent = "0";
            historyTable.hidden = true;
            emptyState.hidden   = false;
            return;
        }

        const total   = scans.length;
        const valid   = scans.filter(s => s.status === "VALID_RECORD").length;
        const failed  = scans.filter(s => s.status !== "VALID_RECORD").length;

        statTotal.textContent  = total;
        statValid.textContent  = valid;
        statFailed.textContent = failed;

        historyBody.innerHTML = scans.map(scan =>
            "<tr>" +
            "<td>" + escapeHTML(scan.productId || "N/A") + "</td>" +
            "<td>" + statusBadge(scan.status) + "</td>" +
            "<td>" + escapeHTML(formatTime(scan.timestamp)) + "</td>" +
            "</tr>"
        ).join("");

        historyTable.hidden = false;
        emptyState.hidden   = true;

    } catch (err) {
        statTotal.textContent  = "—";
        statValid.textContent  = "—";
        statFailed.textContent = "—";
        historyBody.innerHTML =
            '<tr><td colspan="3" style="text-align:center;color:#991b1b;padding:20px">' +
            "Cannot connect to backend. Make sure the server is running at localhost:4000." +
            "</td></tr>";
    }
}

if (refreshBtn) refreshBtn.addEventListener("click", loadHistory);
loadHistory();