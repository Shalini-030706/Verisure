/*
  VeriSure - Public Product Verification
  Calls POST /api/verify on the backend - signature verification is server-side only.
*/
const API_BASE   = "http://localhost:4000/api";
const VALID_ID_FORMAT = /^[A-Za-z0-9_-]{1,60}$/;

const form         = document.getElementById("verifyForm");
const productInput = document.getElementById("productId");
const result       = document.getElementById("result");

function escapeHTML(v) {
    return String(v ?? "").replace(/[&<>"']/g, c => (
        {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]
    ));
}

function detailRow(label, value) {
    const p = document.createElement("p");
    p.className = "result-row";
    p.innerHTML = "<strong>" + escapeHTML(label) + ":</strong> " + escapeHTML(value || "N/A");
    return p;
}

function showMessage(type, heading, body) {
    result.className = "result " + type;
    result.innerHTML =
        "<h3>" + escapeHTML(heading) + "</h3>" +
        "<p>" + escapeHTML(body) + "</p>";
}

form.addEventListener("submit", async function (event) {
    event.preventDefault();

    const productId = productInput.value.trim().toUpperCase();
    result.className = "result";
    result.replaceChildren();

    if (!productId) {
        showMessage("error", "Missing Product ID", "Please enter a product ID.");
        return;
    }
    if (!VALID_ID_FORMAT.test(productId)) {
        showMessage("warning", "Invalid Product ID",
            "Enter an ID such as PROD2001 (letters, digits, hyphens only).");
        return;
    }

    // Show loading state
    result.className = "result";
    result.textContent = "Checking product record...";
    const btn = form.querySelector('[type="submit"]');
    if (btn) btn.disabled = true;

    try {
        // Step 1: fetch the product to get its stored signature for the QR flow,
        // OR just look up the record and display it - no client-side signing.
        // Use GET /api/products/:id to show the record exists.
        const getResp = await fetch(API_BASE + "/products/" + encodeURIComponent(productId));
        const getData = await getResp.json();

        if (!getResp.ok) {
            if (getResp.status === 404) {
                result.className = "result error";
                result.innerHTML =
                    "<h3>Product Not Found</h3>" +
                    "<p>No registered record for <strong>" + escapeHTML(productId) +
                    "</strong>. Its authenticity cannot be confirmed.</p>";
            } else {
                showMessage("warning", "Verification Error",
                    getData.error || "Could not complete verification.");
            }
            return;
        }

        // Record exists - display it clearly as a registry lookup (not a QR scan)
        result.className = "result success";
        result.replaceChildren();

        const heading = document.createElement("h3");
        heading.textContent = "Registered Product Record Found";
        result.append(
            heading,
            detailRow("Product ID",   getData.id),
            detailRow("Product Name", getData.name),
            detailRow("Brand",        getData.brand),
            detailRow("Batch Number", getData.batch),
            detailRow("Status",       getData.status || "REGISTERED")
        );

        const note = document.createElement("p");
        note.className = "result-note";
        note.textContent =
            "This product exists in the VeriSure registry. " +
            "For full cryptographic verification, scan the product QR code.";
        result.append(note);

    } catch (err) {
        showMessage("error", "Backend Connection Failed",
            "Cannot connect to VeriSure backend. Make sure it is running at localhost:4000.");
    } finally {
        if (btn) btn.disabled = false;
    }
});